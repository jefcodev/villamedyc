<?php ?>
<footer style="margin-top: 10%">
    <div class="row footer-credit ">
        <div class="col-md-2"></div>
        <div class="col-md-6">
            <a>Todos los derechos reservados 2018 - Desarrollo: mmjimenez</a>                
        </div>
        <div class="col-md-2">
            <a href="#"><i class="fab fa-facebook-f social-icon"></i></a>                
            <a href="#"><i class="fab fa-youtube social-icon"></i></a>                
        </div>
    </div>
</footer>
<script src="../js/jquery-3.3.1.min.js"></script> 
<!--<script src="../js/bootstrap.min.js"></script>-->
<script src="../js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function () {
        setTimeout(function () {
            $("#mensajes").fadeOut(1500);
        }, 2500);
    });
</script>