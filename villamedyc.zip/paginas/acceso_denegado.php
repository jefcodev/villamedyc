<?php
include 'header.php';

?>

<body>
    <section class="cuerpo">

        <div class="row">

            <div>
                <h1>Acceso denegado</h1>
            </div>

        </div>
    </section>
</body>



<?php
include 'footer.php';
?>